#!/usr/bin/env python3
"""
RackSense - Team Submission Builder
Creates:
Team_Submission/
├── Main_Code.zip
└── Screenshots/
    ├── homepage.png
    ├── feature_1.png
    ├── feature_2.png
    ├── feature_3_simulations.png
    ├── feature_4_forecasts.png
    ├── feature_5_rfid_audit.png
    └── README.md
And packages the whole directory into Team_Submission.zip.
"""

import os
import shutil
import zipfile
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
SUBMISSION_DIR = ROOT_DIR / "Team_Submission"
SCREENSHOTS_DIR = SUBMISSION_DIR / "Screenshots"
MAIN_CODE_ZIP = SUBMISSION_DIR / "Main_Code.zip"
FINAL_ZIP = ROOT_DIR / "Team_Submission.zip"

# Exclude patterns for Main_Code.zip
EXCLUDE_DIRS = {
    "node_modules",
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
    "dist",
    "build",
    "Team_Submission",
}

EXCLUDE_EXTS = {".pyc", ".pyo", ".pyd", ".log"}
EXCLUDE_FILES = {"Team_Submission.zip"}

def should_exclude(rel_path: Path) -> bool:
    for part in rel_path.parts:
        if part in EXCLUDE_DIRS:
            return True
        if part.startswith(".") and part not in {".env.example", ".gitignore", ".agents"}:
            return True
    if rel_path.suffix in EXCLUDE_EXTS:
        return True
    if rel_path.name in EXCLUDE_FILES:
        return True
    return False

def build_main_code_zip():
    print(f"[1/3] Packaging Main_Code.zip from {ROOT_DIR}...")
    SUBMISSION_DIR.mkdir(parents=True, exist_ok=True)
    if MAIN_CODE_ZIP.exists():
        MAIN_CODE_ZIP.unlink()

    included_count = 0
    with zipfile.ZipFile(MAIN_CODE_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(ROOT_DIR):
            rel_dir = Path(root).relative_to(ROOT_DIR)
            
            # Filter dirs in-place to prevent os.walk from descending
            dirs[:] = [d for d in dirs if not should_exclude(rel_dir / d)]
            
            for file in files:
                file_rel = rel_dir / file
                if should_exclude(file_rel):
                    continue
                abs_path = ROOT_DIR / file_rel
                zipf.write(abs_path, arcname=str(file_rel).replace("\\", "/"))
                included_count += 1

    zip_size_mb = MAIN_CODE_ZIP.stat().st_size / (1024 * 1024)
    print(f"  -> Added {included_count} source files to Main_Code.zip ({zip_size_mb:.2f} MB).")

def ensure_screenshots():
    print("[2/3] Setting up Screenshots/ directory...")
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    
    readme_path = SCREENSHOTS_DIR / "README.md"
    readme_content = """# RackSense Screenshots Guide (Phase 2 Submission)

This folder is configured for the required application screenshots as specified in the Phase 2 instructions:

## Required Screenshot Files:
1. **homepage.png**
   - URL: `http://localhost:5173/datacenter`
   - Description: Data Center Dashboard (Site 01 Facility Overview) showing the real-time 3D WebGL data hall (29 racks, 4 rows, walking aisles), live telemetry stats (Nodes Online 2/2), critical path indicators, and top/side navigation bars.

2. **feature_1.png**
   - URL: `http://localhost:5173/datacenter` (with slot selected) OR `http://localhost:5173/datacenter/simulations`
   - Description: Real-time Telemetry & Simulation Engine. Shows measured inlet temperature (24.6 °C), relative humidity, vibration RMS, declared CPU power model (P = P_idle + U * (P_busy - P_idle)), and AI Advisory suggestions with alternative options (Options 1–4).

3. **feature_2.png**
   - URL: `http://localhost:5173/datacenter/audit`
   - Description: Facility Immutable Audit Chain. Shows the green "Audit Chain Cryptographically Verified" banner (verified append-only SHA-256 hash chaining from genesis), head hash, and the "Simulate Tamper" demonstration button.

## Optional Extended Feature Screenshots:
- **feature_3_simulations.png** — Multi-scenario facility stress tests (thermal breach, fan vibration, air stagnation, compute surge) with automated AI mitigations.
- **feature_4_forecasts.png** — Capacity exhaustion distribution cone chart with Theil-Sen slope analysis, ETS damped trend, P10/P50/P90 Monte Carlo cones, and `no_breach_fraction`.
- **feature_5_rfid_login.png** — RFID badge authentication interface (`/login`) with 1-click test cards and cryptographic nonce relay.

*Note: Ready-to-use verified application screenshots are already pre-placed in this directory. You can keep them or replace them with your own fresh captures.*
"""
    readme_path.write_text(readme_content, encoding="utf-8")
    print(f"  -> Screenshots directory verified at {SCREENSHOTS_DIR}")

def build_team_submission_zip():
    print(f"[3/3] Generating final Team_Submission.zip at {FINAL_ZIP}...")
    if FINAL_ZIP.exists():
        FINAL_ZIP.unlink()

    with zipfile.ZipFile(FINAL_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(SUBMISSION_DIR):
            rel_dir = Path(root).relative_to(SUBMISSION_DIR)
            for file in files:
                file_rel = rel_dir / file
                abs_path = SUBMISSION_DIR / file_rel
                # Store with Team_Submission prefix as requested:
                # Team_Submission.zip/
                # ├── Main_Code.zip
                # └── Screenshots/
                arcname = f"Team_Submission/{str(file_rel).replace(chr(92), '/')}"
                zipf.write(abs_path, arcname=arcname)

    zip_size_mb = FINAL_ZIP.stat().st_size / (1024 * 1024)
    print(f"  -> Successfully created Team_Submission.zip ({zip_size_mb:.2f} MB)!")

if __name__ == "__main__":
    build_main_code_zip()
    ensure_screenshots()
    build_team_submission_zip()
